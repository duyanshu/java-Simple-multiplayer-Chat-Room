/*
 * Copyright (c) : All Rights Reserved.FileName: ClientFrame.java
 * @author: YanshuDu
 * @date: 2021/6/19 下午1:51
 * @version: 1.0
 * @Email:2544823286@qq.com
 * 项目名称：java聊天系统
 * 作者：杜研书（YanshuDu）
 * 日期：2021/6/19 下午1:51
 */

package com.YanshuDu;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.LinkedList;

public class ClientFrame extends JFrame {
    //添加Swing组件
    private JTextArea textArea=new JTextArea(10,20);
    private JTextField textField=new JTextField(20);
    private Box box=Box.createVerticalBox();
    private JButton group=new JButton("群聊（所有在线用户）");
    private JLabel jl=new JLabel("在 线 用 户 列 表");
    //IO
    private Socket s=null;
    private DataOutputStream output=null;
    LinkedList<String> portList=new LinkedList<>();
    //定义收件人
    private String receiver="to all\n";

    public ClientFrame() throws HeadlessException {
        init();
    }

    public void init(){
        this.setTitle("客户端窗口");
        textArea.setEnabled(false);
        this.add(box,BorderLayout.WEST);
        this.add(textArea,BorderLayout.CENTER);
        this.add(textField,BorderLayout.SOUTH);
        box.add(group);
        box.add(jl);
        group.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textArea.append("\t群聊\n");
                receiver="to all\n";
            }
        });
        textField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                writeInTextArea(textField.getText());//在文本框中显示输出的文字，并和服务器通信
                textField.setText("");
            }
        });
        this.setBounds(300,200,600,400);
        this.setVisible(true);
        textField.requestFocus();//光标聚焦
        //接受服务器消息
        try {
            s=new Socket("localhost",ServeFrame.port);
            output=new DataOutputStream(s.getOutputStream());//开启输出流
        } catch (IOException e) {
            textArea.append("服务器未运行，请退出等待服务器开启\n");
        }
        textField.setToolTipText("输入文字，按回车发送");
        handleInput();

        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    private void writeInTextArea(String contain){
        if(contain.equals("")) return;
        textArea.append(putBlank(90-contain.length())+contain+'\n');
        handleSent(contain);
    }
    //发送信息到服务器
    public void handleSent(String str){
        try {
            output.writeUTF(receiver+str);//发送收件人+内容
        } catch (IOException e) {
            textArea.append("发送失败，您已被服务器强制下线！");
        }
    }
    public void handleInput(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try (DataInputStream input = new DataInputStream(s.getInputStream())) {
                    while(true){
                        String in=input.readUTF();
                        String[] ss=in.split(" ");
                        if(ss[0].equals("newUser"))
                        {
                            portList.add(ss[1]);
                            JButton jb=new JButton("用户"+ss[1]);
                            box.add(jb);
                            jb.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    receiver="to "+ss[1]+'\n';
                                    textArea.append("\t发送给"+ss[1]+'\n');
                                }
                            });
                        }else
                        textArea.append(in+'\n');
                    }
                }catch (Exception e){
                    textArea.append("您与服务器已断开连接。");
                }
            }
        }).start();
    }


    private String putBlank(int number){
        StringBuilder sb=new StringBuilder();
        for (int i = 0; i < number; i++) {
            sb.append(" ");
        }
        return sb.toString();
    }
}

