/*
 * Copyright (c) : All Rights Reserved.FileName: ServeFrame.java
 * @author: YanshuDu
 * @date: 2021/6/19 下午1:47
 * @version: 1.0
 * 项目名称：java聊天系统
 * 作者：杜研书（YanshuDu）
 * 日期：2021/6/19 下午1:47
 */

package com.YanshuDu;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.Queue;

public class ServeFrame extends JFrame {
    //Swing组件
    public static JTextArea serveTextArea=new JTextArea();
    private JPanel jp=new JPanel();
    private JButton startButton=new JButton("启动服务器");
    private JButton endButton=new JButton("终止服务器");
    private Box box=Box.createVerticalBox();
    private JLabel jl=new JLabel("\t\t成 员 列 表\t\t");
    //TCP连接
    Socket socket=null;
    public static final int port=6666;
    private DataInputStream input=null;
    LinkedList<Handle> list=new LinkedList<>();
    //消息列表
    Queue<String> messageQueue=new LinkedList<>();

    public static void main(String[] args) {
        ServeFrame serveUI=new ServeFrame();
    }

    public ServeFrame(){
        //界面设置
        this.setTitle("Chat Room 服务器");
        this.setBounds(0,200,600,400);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setLayout(new BorderLayout());
        //加入JPanel
        this.add(jp);
        jp.setLayout(new BorderLayout());
        //jp中加入组件
        jp.add(serveTextArea,BorderLayout.CENTER);
        jp.add(startButton,BorderLayout.SOUTH);
        jp.add(box,BorderLayout.EAST);
        this.add(endButton,BorderLayout.SOUTH);
        serveTextArea.setEnabled(false);
        //box属性设置
        box.add(jl);
        //打印服务器状态
        serveTextArea.setFont(new Font("宋体", Font.BOLD,15));

        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ServeSetting();
                startButton.setEnabled(false);
                endButton.setEnabled(true);
            }
        });

//       发送消息队列,新线程
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    while(!messageQueue.isEmpty()){
                        String s=messageQueue.remove();
                        System.out.println(s);
                        String[] ss=s.split("\n");
                        if(ss[1].equals("to all")){
                            for (var v:list) {
                                //给除了自己以外的所有人群发消息
                                if(!v.socket.getRemoteSocketAddress().toString().equals(ss[0])){
                                    v.sentMessage(ss[0]+"(群) : "+ss[2]);
                                }
                            }
                        }else {
                            String socketAddress=ss[1].split(" ")[1];
                            System.out.println("to"+socketAddress);
                            for (var v:list) {
                                //给指定对象发消息
                                if(v.socket.getRemoteSocketAddress().toString().equals(socketAddress)){
                                    v.sentMessage(ss[0]+"(私):"+ss[2]);
                                }
                            }
                        }
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();

        endButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                serveTextArea.append("服务器已关闭\n");
                startButton.setEnabled(true);
                endButton.setEnabled(false);
                closeServer();
            }
        });
    }
    //关闭服务器
    public void closeServer(){
        System.exit(0);
    }

    public void ServeSetting()  {
        try {
            ServerSocket ss=new ServerSocket(port);
            serveTextArea.setText("服务器运行中...\n");
            System.out.println("server is running...");
            Thread t=new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        while(endButton.isEnabled()) {//停止服务器按钮没有被点击
                            socket = ss.accept();
                            String address=socket.getRemoteSocketAddress().toString();
                            serveTextArea.append( address+"上线\n" );
                            Handle tempHandle=new Handle(socket);
                            //有新用户上线，给之前已经上线客户端发送新用户地址
                            for (var v:list
                                 ) {
                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        v.addMember(address);
                                    }
                                }).start();
                            }
                            //显示成员列表
                            displayMember(address,tempHandle);
                            list.add(tempHandle);
                            tempHandle.start();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
            t.start();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public void displayMember(String address,Handle handle){
        Box Hbox=Box.createHorizontalBox();
        Hbox.add(new JLabel(address));
        JButton closeButton=new JButton("强制下线");
        Hbox.add(closeButton);
        box.add(Hbox);
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handle.interrupt();
                closeButton.setEnabled(false);
            }
        });
    }

    class Handle extends Thread{
        private final Socket socket;
        DataOutputStream writer = null;

        public Handle(Socket socket){
            this.socket=socket;
        }

        @Override
        public void run() {
            try(InputStream input=this.socket.getInputStream()) {
                try(OutputStream output=this.socket.getOutputStream()){
                    handle(input,output);
                }
            } catch (IOException | InterruptedException e) {
                try {
                    socket.close();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                e.printStackTrace();
            }
            ServeFrame.serveTextArea.append(socket.getRemoteSocketAddress()+" 已下线"+'\n');

        }

        @Override
        public void interrupt() {
            try {
                socket.getInputStream().close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            super.interrupt();
        }

        private void handle(InputStream input, OutputStream output) throws InterruptedException, IOException {
            writer = new DataOutputStream(output);
            var reader = new DataInputStream(input);
            try {
                writer.writeUTF(socket.getPort()+"欢迎登录!\n");
                //给新上线用户发送所有之前已经存在的用户地址
                sentMemberList(writer);
            } catch (IOException e) {
                e.printStackTrace();
            }
            while(!isInterrupted()) {
                String s = reader.readUTF();
                messageQueue.add(socket.getRemoteSocketAddress()+"\n"+s);//接受客户端请求，在消息队列中加入：请求方+收件方+内容
                ServeFrame.serveTextArea.append(socket.getRemoteSocketAddress()+":"+s+'\n');//打印SocketAddress和该客户端说的话
                System.out.println(socket.toString());
                Thread.sleep(1000);
            }
        }

        private void sentMemberList(DataOutputStream write) throws IOException {
            for (int i = 0; i < list.size()-1; i++) {
                write.writeUTF("newUser "+ list.get(i).socket.getRemoteSocketAddress());
            }
        }
        //有新用户上线，给之前已经上线客户端发送新用户地址
        public void addMember(String address)  {
            try {
                writer.writeUTF("newUser "+address);
            } catch (IOException e) {
                System.out.println("传输成员地址异常");
            }
        }

        public void sentMessage(String message){
            try {
                writer.writeUTF(message);
            } catch (IOException e) {
                System.out.println("消息转发失败");
            }
        }

    }
}
