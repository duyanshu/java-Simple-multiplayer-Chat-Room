/*
 * Copyright (c) : All Rights Reserved.FileName: TheClient.java
 * @author: YanshuDu
 * @date: 2021/6/19 下午1:51
 * @version: 1.0
 * @Email:2544823286@qq.com
 * 项目名称：java聊天系统
 * 作者：杜研书（YanshuDu）
 * 日期：2021/6/19 下午1:51
 */

package com.YanshuDu;

import javax.swing.*;
//客户端程序从这里运行
public class TheClient extends JFrame {
    public static void main(String[] args) {
        new ClientFrame();
    }
}